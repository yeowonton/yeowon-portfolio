import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * MyWorld - Main Game World
 */
public class ControlsScreen extends World
{    
    public static GreenfootSound menuSound = new GreenfootSound("mainmenu.mp3");

    public ControlsScreen()
    {    
        super(1000, 600, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        setBackground("bricks.png");
        setBackground("controlscreen.png");
        playMusic();
        Return button = new Return();
        addObject(button,100,100);
    }
    public void playMusic(){
        menuSound.playLoop();
    }
    public static void end(){
        menuSound.stop();
    }
}
    
