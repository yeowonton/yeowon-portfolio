import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Play here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Control extends menuclicks
{
    public static GreenfootSound controlSound = new GreenfootSound("mainmenu.mp3");
 
    public Control(){
        GreenfootImage i = this.getImage();
        i.scale(160, 160);
        this.setImage(i);
    }
    public void checkClick(World world){
        if (Greenfoot.mouseClicked(this)){
            MainMenu.end();
            Greenfoot.setWorld(world);
        }
    }
    public void act()
    {
        checkMouse();
        checkClick(new ControlsScreen());
    }
}
