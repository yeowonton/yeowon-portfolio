import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * MyWorld - Main Game World
 */
public class MainMenu extends World
{
    public static GreenfootSound menuSound = new GreenfootSound("mainmenu.mp3");
    
    public MainMenu()
    {    
        super(1000, 600, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        setBackground("titlescreen.png");
        playMusic();
        Play play = new Play();   
        Control control = new Control();
        addObject(play,450,400);
        addObject(control,550,400);
    }

    public void playMusic(){
        menuSound.play();
        menuSound.setVolume(10);
    }
    public static void end(){
        menuSound.stop();
    }
}
    
