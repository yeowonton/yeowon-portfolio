import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class menuclicks here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class menuclicks extends Actor
{
    private boolean mouseHover = false;
    private static int maxTrans = 255;
    public void checkMouse()
    {
        if (Greenfoot.mouseMoved(null)){
            mouseHover = Greenfoot.mouseMoved(this);
        }
        if(mouseHover){
            adjTransparency(maxTrans/2);
        }
        else{
            adjTransparency(maxTrans);
        }
    }
    public void checkClick(World world){
        if (Greenfoot.mouseClicked(this)){
            MainMenu.end();
            Greenfoot.setWorld(world);
        }
    }
    public void adjTransparency(int adj){
        GreenfootImage tempImage = getImage();
        tempImage.setTransparency(adj);
        setImage(tempImage);
    }
}
